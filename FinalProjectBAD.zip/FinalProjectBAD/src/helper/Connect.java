package helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Connect {
	
	private final String USERNAME = "root";
	private final String PASSWORD = "";
	private final String DATABASE = "macudonals";
	private final String HOST = "localhost:3306";
	private final String CONNECTION = String.format("jdbc:mysql://%s/%s", HOST, DATABASE);
	
	public Connection con;
	private Statement st;
	public ResultSet rs ;
	private PreparedStatement ps;

	private static Connect connect;
	
	private Connect() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(CONNECTION, USERNAME, PASSWORD);
			st = con.createStatement();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public static Connect getconnect() {
		if (connect == null) {
			return new Connect();
		}
		return connect;
		
	}
	
	

	public ResultSet read (String query) {
		ResultSet rs = null;
		
		try {
			rs = st.executeQuery(query);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return rs;
	}
	
	
	
	public boolean register(String username, String password, String email, String phoneNumber, String address, String gender, String role, String nationality ) {
		
		try {
			ps = con.prepareStatement("INSERT INTO `user` (`username`, `password`, `email`, `phone_number`, `address`, `gender`, `role`, `nationality`) VALUES (?,?,?,?,?,?,?,?);");
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, email);
			ps.setString(4, phoneNumber);
			ps.setString(5, address );
			ps.setString(6, gender);
			ps.setString(7, role);
			ps.setString(8, nationality);
			ps.execute();
			return true;
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;

	}
	
	public void executeUpdate (String query) {
		try {
			st.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	
	public PreparedStatement pStatement(String query) {
		PreparedStatement ps = null;
		
		try {
			ps = con.prepareStatement(query);
		} catch (SQLException e) {
			
			e.printStackTrace();				
		}
		return ps;	
	}
	
	


}
