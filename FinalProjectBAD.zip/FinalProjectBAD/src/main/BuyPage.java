package main;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import helper.Connect;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.window.Window;
import model.Cart;
import model.Food;
import model.User;


public class BuyPage extends Application implements EventHandler<ActionEvent> {

	private BorderPane bPane;
	private MenuBar menubar;
	private Menu menu,account;
	private MenuItem buyFood,manageFood,transaction,logout;
	
	Scene sc;
	BorderPane bp, bpbwh, bpane;
	GridPane gpKanan, gpKiri, gp;
	TableView<Food> marketPlace;
	TableView<Cart> cartTables;
	Text id, name, type, price, stock, qty;
	Text idData, nameData, typeData, priceData, stockData, qtyData;
	Spinner<Integer> qtyS;
	Button addTCartBtn, removeFCartBtn, chckoutBtn;
	Window wins = new Window();
	
	ObservableList<Food> markData;
	ObservableList<Cart> cartData;
	
	Food fSelect = null;
	Cart cSelect = null;
	
	Stage pStage;
	

	public void createAlert(AlertType alertType, String message ) {
		Alert alert = new Alert(alertType);
		alert.setContentText(message);
		alert.showAndWait();
	}

	public void init() {
		menubar = new MenuBar();
		menu = new Menu("Menu");
		account = new Menu("Account");
		menubar.getMenus().add(menu);
		menubar.getMenus().add(account);
		
		buyFood = new MenuItem("Buy Food");
		buyFood.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new BuyPage().openBuyPage();
				pStage.close();
			}
		});
		manageFood = new MenuItem("Manage Food");
		manageFood.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new FoodManageScene().openManage();
				pStage.close();
			}
		});
		transaction = new MenuItem("Transactions");
		transaction.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new TransactionHistoryUser().openTransU();
				pStage.close();
			}
		});
		
		if(User.user.getRole().equalsIgnoreCase("user")){
			menu.getItems().addAll(buyFood, manageFood, transaction);
		} else {
			menu.getItems().addAll( manageFood, transaction);
		}
		logout = new MenuItem("Logout");	
		logout.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new LoginPage().openLogin();
				pStage.close();
			}
		});
		account.getItems().add(logout);
		bp = new BorderPane();
		bpbwh = new BorderPane();
		bpane = new BorderPane();
		gpKanan = new GridPane();
		gpKiri = new GridPane();
		gp = new GridPane();
		bp.setTop(menubar);
		cartData = FXCollections.observableArrayList();
		markData = FXCollections.observableArrayList();
		
		marketPlace = new TableView<>();
		marketPlace.setOnMouseClicked(new EventHandler<Event>() {
			public void handle(Event event) {
				fSelect = marketPlace.getSelectionModel().getSelectedItem();
				gp.getChildren().removeIf(e -> gp.getColumnIndex(e) == 1);
				gp.add(new Label("" + fSelect.getFoodID()), 1, 0);
				gp.add(new Label("" + fSelect.getFoodName()), 1, 1);
				gp.add(new Label("" + fSelect.getFoodType()), 1, 2);
				gp.add(new Label("" + fSelect.getFoodPrice()), 1, 3);
				gp.add(new Label("" + fSelect.getFoodStock()), 1, 4);
			};
		});
		
		cartTables = new TableView<>();
		cartTables.setOnMouseClicked(new EventHandler<Event>() {
			public void handle(Event event) {
				cSelect = cartTables.getSelectionModel().getSelectedItem();
			};
		});
		
		cartTables.getItems().addAll(cartData);
		id = new Text("ID");
		name = new Text("Name");
		type = new Text("Type");
		price = new Text("Price");
		stock = new Text("Stock");
		qty = new Text("Quantity:");


		idData = new Text();
		nameData = new Text();
		typeData = new Text();
		priceData = new Text();
		stockData = new Text();

		qtyS = new Spinner<Integer>(0,1000,0);

		addTCartBtn = new Button("Add to cart");
		removeFCartBtn = new Button("Remove from ...");
		chckoutBtn = new Button("Checkout");
		
		chckoutBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				if(cartTables.getItems().isEmpty()) {
					createAlert(AlertType.ERROR, "No Item to Checkout");
				}
				String query = "INSERT INTO transaction_header (user_id) VALUES('"+ User.user.getId() +"')";
				PreparedStatement ps;
				ResultSet gKey;
				int idss = -1;
				try {
					ps = Connect.getconnect().con.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
					ps.execute();
					 gKey = ps.getGeneratedKeys();
					gKey.next();
					idss = gKey.getInt(1);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
					for(Cart c : cartTables.getItems()) {
						try {
							String query2 = "INSERT INTO transaction_detail VALUES('"+idss+"','"+c.getId()+"','"+c.getQuant()+"','"+ c.getTotal() +"')";
							PreparedStatement ps2 = Connect.getconnect().con.prepareStatement(query2);
							ps2.execute();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					cartTables.getItems().clear();
				}
			
				
			});
		
		removeFCartBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				
					if(cSelect == null) {
						createAlert(AlertType.ERROR, "Please select item to remove from cart");
						return;
					}
					FilteredList<Cart> fList = cartTables.getItems().filtered(p -> p.getId() == cSelect.getId());
					if(fList.size() != 0) {
						
						cartTables.getItems().remove(fList.get(0));
					
					}
				}
			
				
			});
		
		addTCartBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				
					if(fSelect == null) {
						createAlert(AlertType.ERROR, "Please select food before add to cart");
						return;
					}
					
					if(qtyS.getValue() <= 0) {
						createAlert(AlertType.ERROR, "Quantity cannot be 0 or less");
						return;
					}
					
					if(qtyS.getValue() > fSelect.getFoodStock()) {
						createAlert(AlertType.ERROR, "Not Enough Stock");
						return;
					}
				
					FilteredList<Cart> fList = cartTables.getItems().filtered(p -> p.getId() == fSelect.getFoodID());
					if(fList.size() != 0) {
						if( fSelect.getFoodStock() < fList.get(0).getQuant() + qtyS.getValue()) {
							createAlert(AlertType.ERROR, "Not Enough Stock");
							return;
						}
						fList.get(0).setQuant(fList.get(0).getQuant() + qtyS.getValue());
						fList.get(0).setTotal(fList.get(0).getQuant() * fList.get(0).getPrice());
						cartTables.refresh();
						return;
					}
					
					
					
					cartTables.getItems().add(new Cart(
							fSelect.getFoodID(),
							fSelect.getFoodName(),
							fSelect.getFoodPrice(),
							qtyS.getValue(),
							qtyS.getValue() * fSelect.getFoodPrice()
							
						));
				}
			
				
			});

		sc = new Scene(bpane, 1000, 700);
	}
	
	
	

	public void addComponent() {


		gpKiri.add(id, 0, 0);
		gpKiri.add(name, 0, 1);
		gpKiri.add(type, 0, 2);
		gpKiri.add(price, 0, 3);
		gpKiri.add(stock, 0, 4);

		gpKiri.add(idData, 0, 0);
		gpKiri.add(nameData, 0, 1);
		gpKiri.add(typeData, 0, 2);
		gpKiri.add(priceData, 0, 3);
		gpKiri.add(stockData, 0, 4);
		
		gpKiri.setVgap(35);
		gpKiri.setHgap(40);
		

		setTable();

		gp.add(qty, 2, 0);
		gp.add(qtyS, 2, 1);
		gp.add(addTCartBtn, 2, 2);
		gp.add(removeFCartBtn, 2, 3);
		gp.add(chckoutBtn, 2, 4);

		gp.setVgap(20);
		gp.setHgap(40);
	
		GridPane.setMargin(gp, new Insets(20, 0, 20, 0));
		
		gpKanan.add(gp, 0, 0);
		gpKanan.add(cartTables, 1, 0);
		gpKanan.setHgap(20);

		bpbwh.setLeft(gpKiri);
		bpbwh.setRight(gpKanan);
		BorderPane.setMargin(gpKiri, new Insets(20, 0, 20, 0));

		bp.setCenter(marketPlace);
		bp.setBottom(bpbwh);
		BorderPane.setMargin(bpbwh, new Insets(10));

		getSetData();
		
		wins.setPrefSize(bp.getPrefWidth(), bp.getPrefHeight());
		wins.setTitle("Buy Food");
		wins.getContentPane().getChildren().add(bp);
		bpane.setCenter(wins);

	}
	
	
	public void style() {
		qtyS.setPrefSize(150, 20);
		addTCartBtn.setPrefSize(150, 20);
		removeFCartBtn.setPrefSize(150, 20);
		chckoutBtn.setPrefSize(150, 20);
	}
	void getSetData() {
		ResultSet hasil = Connect.getconnect().read("SELECT * FROM food");
		ArrayList<Food> foods = new ArrayList<>();
		try {
			while(hasil.next()) {
				try {
					foods.add(new Food(hasil.getInt("id"), hasil.getString("name"), hasil.getString("type"), hasil.getInt("price"), hasil.getInt("stock")));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		marketPlace.setItems(FXCollections.observableArrayList(foods));
		
		
	}
	public void setTable() {

		TableColumn <Food, Integer>idK = new TableColumn<>("ID");
		TableColumn <Food, String>nameK = new TableColumn<>("Name");	
		TableColumn <Food, String>typeK = new TableColumn<>("Type");
		TableColumn <Food, String>priceK = new TableColumn<>("Price");
		TableColumn <Food, String>stockK = new TableColumn<>("Stock");
		idK.setCellValueFactory(new PropertyValueFactory<>("foodID"));
		nameK.setCellValueFactory(new PropertyValueFactory<>("foodName"));
		typeK.setCellValueFactory(new PropertyValueFactory<>("foodType"));
		priceK.setCellValueFactory(new PropertyValueFactory<>("foodPrice"));
		stockK.setCellValueFactory(new PropertyValueFactory<>("foodStock"));
				
		marketPlace.getColumns().addAll(idK,nameK, typeK, priceK, stockK);

		idK.setPrefWidth(sc.getWidth()/5);
		nameK.setPrefWidth(sc.getWidth()/5);
		typeK.setPrefWidth(sc.getWidth()/5);
		priceK.setPrefWidth(sc.getWidth()/5);
		stockK.setPrefWidth(sc.getWidth()/5);


	

		TableColumn<Cart, Integer> idFK = new TableColumn<>("Food ID");
		TableColumn<Cart, String> nameFK = new TableColumn<>("Food Name");
		TableColumn<Cart, Integer> priceFK = new TableColumn<>("Food Price");
		TableColumn<Cart, Integer> quantityFK = new TableColumn<>("Quantity");
		TableColumn<Cart, Integer> totalPriceFK = new TableColumn<>("Total Price");

		idFK.setCellValueFactory(new PropertyValueFactory<>("id"));
		nameFK.setCellValueFactory(new PropertyValueFactory<>("name"));
		priceFK.setCellValueFactory(new PropertyValueFactory<>("price"));
		quantityFK.setCellValueFactory(new PropertyValueFactory<>("quant"));
		totalPriceFK.setCellValueFactory(new PropertyValueFactory<>("total"));

		cartTables.getColumns().addAll(idFK,nameFK, priceFK, quantityFK, totalPriceFK);
	
		cartTables.setPrefSize(525, 250);
		idFK.setPrefWidth(525/5);
		nameFK.setPrefWidth(525/5);
		priceFK.setPrefWidth(525/5);
		quantityFK.setPrefWidth(525/5);
		totalPriceFK.setPrefWidth(525/5);

		
	}
	
	public Scene showBuyPage() {
		init();
		addComponent();
		style();
		setTable();
		return sc;
	}
	
	void openBuyPage() {
		pStage = new Stage();
		pStage.setScene(showBuyPage());
		pStage.show();
	}
	
	
	
	
	@Override
	public void handle(ActionEvent event) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		Stage st = new Stage();
		st.setScene(showBuyPage());
		st.show();
	}

}
