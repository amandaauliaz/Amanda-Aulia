package main;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import helper.Connect;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.window.Window;
import model.Food;
import model.User;

public class FoodManageScene extends Application {

	Scene sc;
	BorderPane bp, bpane;
	GridPane gp;
	Text foodidTxt, foodNameTxt, foodTypeTxt, foodPriceTxt, foodStockTxt;
	private BorderPane bPane;
	private MenuBar menubar;
	private Menu menu,account;
	private MenuItem buyFood,manageFood,transaction,logout;
	TableView<Food> manageFoodtable;
	TextField foodId, foodName, foodPrice;
	ComboBox<String> foodType;
	Spinner<Integer> foodStockSpinner;
	Button insertTombol, updateTombol, deleteTombol;
	
	Window wins = new Window();
	
	Food choosed = null;
	
	
	public FoodManageScene() {
		initial();
		addComponent();
		window();
	}
	Stage pStage;
	private void createMsg (String message) {
		  Alert alert = new Alert(AlertType.ERROR);    
	      alert.setContentText(message);
	      alert.show();
	}
	public void initial() {
		menubar = new MenuBar();
		menu = new Menu("Menu");
		account = new Menu("Account");
		menubar.getMenus().add(menu);
		menubar.getMenus().add(account);
		
		buyFood = new MenuItem("Buy Food");
		buyFood.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new BuyPage().openBuyPage();
				pStage.close();
			}
		});
		manageFood = new MenuItem("Manage Food");
		manageFood.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new FoodManageScene().openManage();
				pStage.close();
			}
		});
		transaction = new MenuItem("Transactions");
		transaction.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new TransactionHistoryUser().openTransU();
				pStage.close();
			}
		});
		
		if(User.user.getRole().equalsIgnoreCase("user")){
			menu.getItems().addAll(buyFood, manageFood, transaction);
		} else {
			menu.getItems().addAll( manageFood, transaction);
		}
		logout = new MenuItem("Logout");	
		logout.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new LoginPage().openLogin();
				pStage.close();
			}
		});
		account.getItems().add(logout);
		bp = new BorderPane();
		bpane = new BorderPane();
		gp = new GridPane();
		bp.setTop(menubar);
		
		foodidTxt = new Text("ID");
		foodNameTxt = new Text("Name");
		foodTypeTxt = new Text("Type");
		foodPriceTxt = new Text("Price");
		foodStockTxt = new Text("Stock");
		
		manageFoodtable = new TableView<>();	
		foodName = new TextField();
		foodPrice = new TextField();
		
		ObservableList<String> ftList = FXCollections.observableArrayList();
		ftList.add("Main Dish");
		ftList.add("Appetizer");
		ftList.add("Drink");
		ftList.add("Dessert");
		ftList.add("Side dish");
		getSetData();
		foodType = new ComboBox<>(ftList);
		
		foodStockSpinner = new Spinner<Integer>(0,1000,0);
		
		insertTombol = new Button("Insert");
		updateTombol = new Button("Update");
		deleteTombol = new Button("Delete");
		
		manageFoodtable.setOnMouseClicked(new EventHandler<Event>() {
			public void handle(Event event) {
				choosed = manageFoodtable.getSelectionModel().getSelectedItem();		
				if(choosed != null) {
					foodidTxt.setText("ID : " + choosed.getFoodID());
				}
			};
		});
		
		insertTombol.setOnAction( new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				
				if(!verifikasiInsert()) {
					return;
				}
				
				String fName = foodName.getText();
				String fPrice = foodPrice.getText();
				String fType = foodType.getValue();
				Integer fStock = foodStockSpinner.getValue();
				
				String query = "INSERT INTO food (name,type,price,stock) VALUES('"+fName+"','"+fType+"','"+fPrice+"','"+fStock+"')";
				try {
					PreparedStatement ps = Connect.getconnect().con.prepareStatement(query);
					ps.execute();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				getSetData();
			}
		});
		
		updateTombol.setOnAction( new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				if(!verifikasiUpdate()) {
					return;
				}
				// TODO Auto-generated method stub
				String fName = foodName.getText();
				String fPrice = foodPrice.getText();
				String fType = foodType.getValue();
				Integer fStock = foodStockSpinner.getValue();
				
				String query = "UPDATE food SET name = '" + fName+"',"
						+ "type = '"+fType+"',"
						+ "price = '"+fPrice+"',"
						+ "stock = '"+fStock+"'"
						+ "WHERE id = " + choosed.getFoodID();
				try {
					PreparedStatement ps = Connect.getconnect().con.prepareStatement(query);
					ps.execute();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				getSetData();
			}
		});
		
		deleteTombol.setOnAction( new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				String fName = foodName.getText();
				String fPrice = foodPrice.getText();
				String fType = foodType.getValue();
				Integer fStock = foodStockSpinner.getValue();
				
				String query = "DELETE FROM food WHERE id = " + choosed.getFoodID() ;
				try {
					PreparedStatement ps = Connect.getconnect().con.prepareStatement(query);
					ps.execute();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				createAlert(AlertType.INFORMATION, "Deleting Food");
				getSetData();
			}
		});
		
		
		sc = new Scene(bpane, 1000, 700);
	}
	boolean verifikasiInsert() {
		if(foodName.getText().isEmpty() || foodPrice.getText().isEmpty() || foodType.getValue() == null || foodType.getValue().equals("")) {
			createAlert(AlertType.ERROR,"Field must be filled");
			return false;
			
		}else if (foodStockSpinner.getValue() <= 0) {
			createAlert(AlertType.ERROR,"Stock cannot be 0 or less");
			return false;
			
		} else if (!foodPrice.getText().matches("[0-9]+")) {
			createAlert(AlertType.ERROR,"Input is not numeric");
			return false;
			
		} else if (Integer.valueOf(foodPrice.getText()) <= 0) {
			createAlert(AlertType.ERROR,"Price cannot be 0 or less");
			return false;
		} else if (foodName.getText().length() < 5 || foodName.getText().length() > 30) {
			createAlert(AlertType.ERROR,"Food Name length more than 5-30");
			return false;
			
		}  
		return true;
	}
	public void createAlert(AlertType alertType, String message ) {
		Alert alert = new Alert(alertType);
		alert.setContentText(message);
		alert.showAndWait();
	}
	boolean verifikasiUpdate() {
		if(choosed == null) {
			createAlert(AlertType.ERROR,"Please choose food to update");
			return false;
			
		} else if(foodName.getText().isEmpty() || foodPrice.getText().isEmpty() || foodType.getValue() == null || foodType.getValue().equals("")) {
			createAlert(AlertType.ERROR,"Field must be filled");
			return false;
			
		}else if (foodStockSpinner.getValue() <= 0) {
			createAlert(AlertType.ERROR,"Stock cannot be 0 or less");
			return false;
			
		} else if (!foodPrice.getText().matches("[0-9]+")) {
			createAlert(AlertType.ERROR,"Input is not numeric");
			return false;
			
		} else if (Integer.valueOf(foodPrice.getText()) <= 0) {
			createAlert(AlertType.ERROR,"Price cannot be 0 or less");
			return false;
		} else if (foodName.getText().length() < 5 || foodName.getText().length() > 30) {
			createAlert(AlertType.ERROR,"Food Name length more than 5-30");
			return false;
		}  
		return true;
	}
	void getSetData() {
		ResultSet hasil = Connect.getconnect().read("SELECT * FROM food");
		ArrayList<Food> foods = new ArrayList<>();
		try {
			while(hasil.next()) {
				try {
					foods.add(new Food(hasil.getInt("id"), hasil.getString("name"), hasil.getString("type"), hasil.getInt("price"), hasil.getInt("stock")));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		manageFoodtable.setItems(FXCollections.observableArrayList(foods));
		
		
	}
	
	public void window() {
		//bpane.setTop();//isi menu bar nantinya
		wins.setPrefSize(bp.getPrefWidth(), bp.getPrefHeight());
		wins.setTitle("Manage Food");
		wins.getContentPane().getChildren().add(bp);
		bpane.setCenter(wins);
	}
	
	public void addComponent() {
		gp.add(foodidTxt, 0, 0);
		gp.add(foodNameTxt, 0, 1);
		gp.add(foodTypeTxt, 0, 2);
		gp.add(foodPriceTxt, 0, 3);
		gp.add(foodStockTxt, 0, 4);
		
		gp.add(foodName, 1, 1);
		foodName.setPrefSize(320, 15);
		gp.add(foodType, 1, 2);
		foodType.setPrefSize(320, 15);
		gp.add(foodPrice, 1, 3);
		foodPrice.setPrefSize(320, 15);
		gp.add(foodStockSpinner, 1, 4);
		foodStockSpinner.setPrefSize(320, 15);
		
		if(User.user.getRole().equalsIgnoreCase("administrator")) {
			gp.add(insertTombol, 2, 1);
			insertTombol.setPrefSize(180, 10);
			gp.add(updateTombol, 2, 2);
			updateTombol.setPrefSize(180, 10);
			gp.add(deleteTombol, 2, 4);
			deleteTombol.setPrefSize(180, 10);
		}
		
		gp.setVgap(10);
		gp.setHgap(30);
		
		setTable();
		
		bp.setCenter(manageFoodtable);
		bp.setBottom(gp);
		gp.setAlignment(Pos.CENTER);
		BorderPane.setMargin(gp, new Insets(30, 0, 30, 0));
		BorderPane.setAlignment(gp, Pos.CENTER);
	}
	public void setTable() {
		
		TableColumn idFK = new TableColumn<>("ID");
		TableColumn nameFK = new TableColumn<>("Name");
		TableColumn typeFK = new TableColumn<>("Type");
		TableColumn priceFK = new TableColumn<>("Price");
		TableColumn qtyFK = new TableColumn<>("Stock");
		
		idFK.setCellValueFactory(new PropertyValueFactory<>("foodID"));
		nameFK.setCellValueFactory(new PropertyValueFactory<>("foodName"));
		typeFK.setCellValueFactory(new PropertyValueFactory<>("foodType"));
		priceFK.setCellValueFactory(new PropertyValueFactory<>("foodPrice"));
		qtyFK.setCellValueFactory(new PropertyValueFactory<>("foodStock"));

		idFK.setPrefWidth(sc.getWidth()/5);
		nameFK.setPrefWidth(sc.getWidth()/5);
		typeFK.setPrefWidth(sc.getWidth()/5);
		priceFK.setPrefWidth(sc.getWidth()/5);
		qtyFK.setPrefWidth(sc.getWidth()/5);

		manageFoodtable.getColumns().addAll(idFK,nameFK, typeFK, priceFK, qtyFK);
	}
	
	public Scene getFoodManageScene() {
		return sc;
	}
	
	void openManage() {
		pStage = new Stage();
		pStage.setScene(getFoodManageScene());
		pStage.show();
	}
	
	
	@Override
	public void start(Stage arg0) throws Exception {
		Stage st = new Stage();
		FoodManageScene scne = new FoodManageScene();
		st.setScene(scne.getFoodManageScene());
		st.show();
		
	}

}
