package main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import helper.Connect;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.User;

public class LoginPage {
	
	private Scene scene;
	private BorderPane bPane, bp;
	private GridPane gPane;
	private Label emailLabel,passwordLabel; 
	private TextField emailField;
	private PasswordField passwordField;
	private Button loginButton;
	private Hyperlink hyperLink;
	private Text login;
	private FlowPane fp1, fp2;;
	private Stage pStage;
	
	
	Connect con = Connect.getconnect();
	
	private String uTemp, pTemp;
	private int idUser;
	static ArrayList<User> uList;
	
	public void init() {
		
			// flowpane
			fp1 = new FlowPane();
			fp2 = new FlowPane();
				 
			// init container
			gPane = new GridPane();
			bPane = new BorderPane();
			bp = new BorderPane();
				
			// init label
			emailLabel = new Label("Email");
			passwordLabel = new Label ("Password");
				
			// init textField
			login = new Text("LOGIN");
		
			emailField = new TextField();
			emailField.setPromptText("Input Email");
				
			// init password
			passwordField = new PasswordField();
			passwordField.setPromptText("Input Password");
				
			// init button
			loginButton = new Button("Login");
			
			// init hyperlink
			hyperLink = new Hyperlink("Dont have account? Register here");
	}
	
	
	public void addComponent () {

		login.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 30));
		gPane.add(emailLabel, 0, 1);
		gPane.add(emailField, 1, 1);
		//emailField.setPrefSize(150, 100);
		
		gPane.add(passwordLabel, 0, 2);
		gPane.add(passwordField, 1, 2);
		passwordField.setPrefWidth(170);//(150, 100);
		passwordField.setPrefHeight(40);
		
		gPane.add(loginButton, 0, 3);
		loginButton.setPrefSize(70, 30);
		loginButton.setTextFill(Color.WHITE);
		loginButton.setStyle("-fx-background-color: red;");
		
		gPane.add(hyperLink, 0, 5);
		
		scene = new Scene (bPane, 500,300);
	}
	  
	
	public void arrangeComponent () {
		
		BorderPane.setAlignment(login, Pos.CENTER);
		gPane.setVgap(20);
		gPane.setHgap(20);
		gPane.setAlignment(Pos.CENTER);
		
		bp.setCenter(gPane);
		bp.setBottom(loginButton);
		BorderPane.setAlignment(loginButton, Pos.CENTER);
		
		bPane.setPadding(new Insets(10,10,10,10));
		bPane.setTop(login);
		bPane.setCenter(bp);
		bPane.setBottom(hyperLink);
		BorderPane.setAlignment(hyperLink, Pos.CENTER);
		
		BorderPane.setMargin(login, new Insets(20, 0, 0, 0));
		BorderPane.setMargin(bp, new Insets(20, 0, 0, 0));
		BorderPane.setMargin(loginButton, new Insets(20, 0, 0, 0));
		BorderPane.setMargin(hyperLink, new Insets(20, 0, 20, 0));
		
		
		// Set Background Color
		BackgroundFill backgroundColor  = new BackgroundFill(Color.web("#F7d226"), null, null);
		Background background = new Background (backgroundColor);
		bPane.setBackground(background);
		
	}

	void openLogin() {
		pStage = new Stage();
		pStage.setScene(showLoginPage());
		pStage.show();
	}
	
	private void login() {
		String query = "SELECT * FROM User";
		uList = new ArrayList<>();
		ResultSet rs = con.read(query);
		
		try {
			while (rs.next()) {
				User temp = new User(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));

				uList.add(temp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
			
	public void addMouseEvent() {
		hyperLink.setOnMouseClicked(new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				// TODO Auto-generated method stub
				new Regist().openRegist();
				pStage.close();
			}});
	}
	
	public Scene showLoginPage() {
		init();
		addComponent();
		login();
		arrangeComponent();
		setEventHandler();
		addMouseEvent();
		return scene;
	}
	
	

	public void setEventHandler() {
		loginButton.setOnAction( new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				
				
				
				for(User u : uList) {
					
					if(u.getEmail().equals(emailField.getText()) && u.getPassword().equals(passwordField.getText())) {
						System.out.println(u.getEmail() + "\n" + u.getPassword() +"\n");
						System.out.println(u.getId());
						if(u.getRole().equalsIgnoreCase("user")) {
							User.user = u;
							new MainFormUser().openMainFormUser();
							pStage.close();
							return;
						} else {
							User.user = u;
							new MainFormAdmin().openMainFormUser();
							pStage.close();
							return;
						}
					}
				}
				
				createAlert(AlertType.ERROR, "Incorrect email/password");
				
			}
		});
	}
	

	public void createAlert(AlertType alertType, String message ) {
		Alert alert = new Alert(alertType);
		alert.setContentText(message);
		alert.showAndWait();	
	}


}
