package main;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.login.Login;

public class Main extends Application{
	
		/* KELOMPOK PROJECT BUSINESS APPLICATION DEVELOPMENT BF11 -
		 * 1	2501992721	Arvinsani Athanzah
		 * 2	2501995622	Dima Yudhatama
		 * 3	2501994525	Djatidhammo Putrasidharta Wijayo
		 * 4	2501998624	Michael Yohannes Turisno
		 */

	private static Stage mainStage;
	
	@Override
	public void start(Stage stage) throws Exception {
		new LoginPage().openLogin();
		stage.setTitle("Macudonals");
	}

	
	
	public static void main(String[] args) {
		launch(args);

	}
}