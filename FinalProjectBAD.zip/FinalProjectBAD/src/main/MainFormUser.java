package main;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.User;

public class MainFormUser extends Application {

	private Scene scene;
	private BorderPane bPane;
	private MenuBar menubar;
	private Menu menu,account;
	private MenuItem buyFood,manageFood,transaction,logout;
	Stage pStage;


	public void init() {
		bPane = new BorderPane();
		
		menubar = new MenuBar();
		menu = new Menu("Menu");
		account = new Menu("Account");
		menubar.getMenus().add(menu);
		menubar.getMenus().add(account);
		
		buyFood = new MenuItem("Buy Food");
		buyFood.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new BuyPage().openBuyPage();
				pStage.close();
			}
		});
		manageFood = new MenuItem("Manage Food");
		manageFood.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new FoodManageScene().openManage();
				pStage.close();
			}
		});
		ImageView iv = new ImageView();
		Image macuDonals = new Image("file:src/main/macudonals.png", 250, 250, false, false);
		iv.setImage(macuDonals);
		bPane.setCenter(iv);
		transaction = new MenuItem("Transactions");
		transaction.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new TransactionHistoryUser().openTransU();
				pStage.close();
			}
		});
		
		if(User.user.getRole().equalsIgnoreCase("user")){
			menu.getItems().addAll(buyFood, manageFood, transaction);
		} else {
			menu.getItems().addAll( manageFood, transaction);
		}
		logout = new MenuItem("Logout");	
		logout.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new LoginPage().openLogin();
				pStage.close();
			}
		});
		account.getItems().add(logout);
		
		bPane.setTop(menubar);
		bPane.setAlignment(menubar, Pos.CENTER);
		
		scene = new Scene(bPane,900,500);
		
		
	}

	void openMainFormUser() {
		pStage = new Stage();
		pStage.setScene(showMainFormUser());
		pStage.show();
	}
	
	public Scene showMainFormUser() {
		init();
		return scene;
	}


	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		pStage = new Stage();
		pStage.setScene(showMainFormUser());
		pStage.show();
	}
	
	
	
	
}
