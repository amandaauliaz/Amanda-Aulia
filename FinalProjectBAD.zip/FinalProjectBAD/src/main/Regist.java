package main;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import helper.Connect;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Regist implements EventHandler<ActionEvent> {

	
	private Scene scene;
	private BorderPane bPane, bp;
	private GridPane gPane;
	private Text titleTxt, nameTxt, emailTxt, passwordText, confirmPasswordTxt, genderTxt, phoneTxt, addressTxt, nationalityTxt;
	private TextField nameField, emailField, phoneField;
	private PasswordField passworldField,confirmPasswordField;
	private RadioButton maleRB, femaleRB;
	private TextArea address;
	private ComboBox<String> nationality;
	private Button register;
	private Hyperlink hyperlink;
	private ToggleGroup genderTG;
	private FlowPane fp;
	Stage pStage;
	Connect con = Connect.getconnect();
	
public void init() {
		
	// init container
	gPane = new GridPane();
	bPane = new BorderPane();
	bp = new BorderPane();
	fp = new FlowPane();

	// init text
	titleTxt = new Text("REGISTER");
	nameTxt = new Text("Name");
	emailTxt = new Text("Email");
	passwordText = new Text("Password");
	confirmPasswordTxt = new Text("Confirm Password");
	genderTxt = new Text("Gender");
	phoneTxt = new Text("Phone Number");
	addressTxt = new Text("Address");
	nationalityTxt = new Text("Nationality");

	// init textfield
	nameField = new TextField();
	emailField = new TextField();
	phoneField = new TextField();

	// init PasswordField

	passworldField = new PasswordField();
	confirmPasswordField = new PasswordField();

	// init radiobutton
	maleRB = new RadioButton("Male");
	femaleRB = new RadioButton ("Female");
	genderTG = new ToggleGroup();

	maleRB.setToggleGroup(genderTG);
	femaleRB.setToggleGroup(genderTG);

	// init address
	address = new TextArea("");

	//init nationality
	nationality = new ComboBox();
	nationality.getItems().add("Indonesia");
	nationality.getItems().add("Korea");
	nationality.getItems().add("Malay");
	nationality.getItems().add("Papua Nuginis");
	nationality.getItems().add("Israel");

	// init button
	register = new Button("Register");
	register.setOnAction(new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// TODO Auto-generated method stub
			String nameT,emailT, passT,conT, phoneT, addressT;
			nameT = nameField.getText();
			emailT = emailField.getText();
			passT = passworldField.getText();
			conT = confirmPasswordField.getText();
			phoneT = phoneField.getText();
			addressT = address.getText();
			
			if (nameT.isEmpty() || emailT.isEmpty() || passT.isEmpty() || conT.isEmpty() || phoneT.isEmpty() || addressT.isEmpty()) {
				createAlert(AlertType.ERROR, "All field must be filled");
				return;
			} else if (nameT.length() < 5 || nameT.length() > 20) {
				createAlert(AlertType.ERROR, "Username must be between 5-20 length");
				return;
			} else if (passT.length() < 5 || passT.length() > 20) {
				createAlert(AlertType.ERROR, "password must be between 5-20 length");
				return;
			} else if (!passT.matches("[A-Za-z0-9]+")) {
				createAlert(AlertType.ERROR, "password must be consist alphanumeric");
				return;
			} else if (!conT.equals(passT)) {
				createAlert(AlertType.ERROR, "password not match! please refill the password");
				return;
			} else if (!emailT.contains("@email.com")) {
				createAlert(AlertType.ERROR, "email must in name@email.com format");
				return;
			} else if (!addressT.endsWith("street")) {
				createAlert(AlertType.ERROR, "street must be ended with 'street' ");
				return;
			} else if (!(maleRB.isSelected() || femaleRB.isSelected())) {
				createAlert(AlertType.ERROR, "gender must be choosed!' ");
				return;
			} else if (nationality.getValue() == null) {
				createAlert(AlertType.ERROR, "Your nationality hasnt been choose ");
				return;
			} else if (!phoneT.matches("[0-9]+")) {
				createAlert(AlertType.ERROR, "PhoneNumber must be numerical!");
				return;
			} else if (emailCheck()) {
				createAlert(AlertType.ERROR, "email already exists, choose another one!");
				return;
			} 
			
			RadioButton rb = (RadioButton) genderTG.getSelectedToggle();
			String query2 = "INSERT INTO user (username,password,email,phone_number,address,gender,role,nationality) "
					+ "VALUES('"+nameT+"','"+passT+"','"+emailT+"','"+ phoneT +"','"+ addressT +"','"+ rb.getText() +"','"+ "user" +"','"+ nationality.getValue() +"')";
			PreparedStatement ps2;
			try {
				ps2 = Connect.getconnect().con.prepareStatement(query2);
				ps2.execute();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			new LoginPage().openLogin();
			pStage.close();
		}
	});
	
	// init hyperlink
	hyperlink = new Hyperlink("Already have account? Login here!");
	
	}
	

		public void addComponent() {
	
			//gPane.add(titleTxt, 1, 0);
			titleTxt.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 20));

			gPane.add(nameTxt, 0, 1);
			gPane.add(nameField, 1, 1);

			gPane.add(emailTxt, 0, 2);
			gPane.add(emailField, 1,2);

			gPane.add(passwordText, 0, 3);
			gPane.add(passworldField, 1, 3);

			gPane.add(confirmPasswordTxt, 0, 4);
			gPane.add(confirmPasswordField, 1, 4);

			fp.getChildren().add(maleRB);
			fp.getChildren().add(femaleRB);
			fp.setHgap(30);
			fp.setAlignment(Pos.CENTER);
			
			gPane.add(genderTxt, 0, 5);
			gPane.add(fp, 1, 5);


			gPane.add(phoneTxt, 0, 6);
			gPane.add(phoneField, 1, 6);

			gPane.add(addressTxt, 0, 7);
			gPane.add(address, 1, 7);
			address.setPrefHeight(40);

			gPane.add(nationalityTxt, 0, 8);
			gPane.add(nationality, 1, 8);
			
			nameField.setPrefWidth(400);
			emailField.setPrefWidth(400);
			passworldField.setPrefWidth(400);
			confirmPasswordField.setPrefWidth(400);
			address.setPrefWidth(400);
			nationality.setPrefWidth(400);

			bp.setCenter(gPane);
			bp.setBottom(register);
			register.setPrefWidth(100);

			
			register.setTextFill(Color.WHITE);
			register.setStyle("-fx-background-color: red;");

		}
		
		
		
		public void arrangeComponent() {	
			gPane.setVgap(20);
			gPane.setHgap(35);
			gPane.setAlignment(Pos.CENTER);
			bPane.setPadding(new Insets(10,10,10,10));
			bPane.setTop(titleTxt);
			bPane.setCenter(bp);
			bPane.setBottom(hyperlink);
			gPane.setAlignment(Pos.CENTER);

			BorderPane.setAlignment(titleTxt, Pos.CENTER);
			BorderPane.setAlignment(register, Pos.CENTER);
			BorderPane.setAlignment(hyperlink, Pos.CENTER);
			
			BorderPane.setMargin(bp, new Insets(0, 0, 30, 0));
			BorderPane.setMargin(titleTxt, new Insets(50, 0, 0, 0));
			BorderPane.setMargin(register, new Insets(10, 0, 0, 0));
			BorderPane.setMargin(hyperlink, new Insets(0, 0, 20, 0));
			// Set Background 
			BackgroundFill backgroundColor  = new BackgroundFill(Color.web("#F7d226"), null, null);
			Background background = new Background (backgroundColor);
			bPane.setBackground(background);

			scene = new Scene(bPane,1000,600);
	
		}
		


	public void createAlert(AlertType alertType, String message ) {
		Alert alert = new Alert(alertType);
		alert.setContentText(message);
		alert.showAndWait();
	}
	

	
	public boolean emailCheck() {
		
		String checkEmail = emailField.getText();
		
		String query = "SELECT * FROM user";
		
		ResultSet rs = con.read(query);
		
		try {
			while (rs.next()) {
				if (checkEmail.equals(rs.getString(4))) {
					return true;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}

	void openRegist() {
		pStage = new Stage();
		pStage.setScene(showRegistPage());
		pStage.show();
	}

	@Override
	public void handle(ActionEvent e) {
		
		
		if (e.getSource() == register) {

			
		
			
		} 
		
		
	}
	

	
	
	

	
	public void goToLoginPage() {
		 new LoginPage().openLogin();
		
	}
	
	public Scene showMainFormUser() {
		init();
		addComponent();
		arrangeComponent();
		addMouseEvent();	
		return scene;
	}
	
	
	public Scene showRegistPage() {
		init();
		addComponent();
		arrangeComponent();
		setEventHandler();
		addMouseEvent();
		return scene;
	}
	
	
	
	public void setEventHandler() {
		hyperlink.setOnAction(this);
	}
	
	public void addMouseEvent() {
		hyperlink.setOnMouseClicked(evt -> {
			new LoginPage().openLogin();
			pStage.close();
		});
	}

	
	
}
