package main;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import helper.Connect;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.window.Window;
import model.TD;
import model.TH;
import model.User;

public class TransactionHistoryAdmin extends Application {
	Stage pStage;
	Scene sc;
	BorderPane bp1, bp2, bp, bpane;
	Window wins = new Window();
	private BorderPane bPane;
	private MenuBar menubar;
	private Menu menu,account;
	private MenuItem buyFood,manageFood,transaction,logout;
	TableView<TD> transactionTable;
	TableView<TH> userTable;
	
	ObservableList<TH> thData;
	ObservableList<TD> tDData;
	
	public TransactionHistoryAdmin() {
		// TODO Auto-generated constructor stub
		initilize();
		window();
		addComponent();
	}
	void openTransA() {
		pStage = new Stage();
		pStage.setScene(getTransactionHistoryAdmin());
		pStage.show();
	}
	void initilize() {
		bp = new BorderPane();
		bp1 = new BorderPane();
		bp2 = new BorderPane();
		bpane = new BorderPane();
		menubar = new MenuBar();
		menu = new Menu("Menu");
		account = new Menu("Account");
		menubar.getMenus().add(menu);
		menubar.getMenus().add(account);
		
		buyFood = new MenuItem("Buy Food");
		buyFood.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new BuyPage().openBuyPage();
				pStage.close();
			}
		});
		manageFood = new MenuItem("Manage Food");
		manageFood.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new FoodManageScene().openManage();
				pStage.close();
			}
		});
		transaction = new MenuItem("Transactions");
		transaction.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new TransactionHistoryUser().openTransU();
				pStage.close();
			}
		});
		
		if(User.user.getRole().equalsIgnoreCase("user")){
			menu.getItems().addAll(buyFood, manageFood, transaction);
		} else {
			menu.getItems().addAll( manageFood, transaction);
		}
		logout = new MenuItem("Logout");	
		logout.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				new LoginPage().openLogin();
				pStage.close();
			}
		});
		account.getItems().add(logout);
		bp.setTop(menubar);
		transactionTable = new TableView<>();
		userTable = new TableView<>();
		
		ResultSet result = Connect.getconnect().read("SELECT transaction_id, "
				+ "user_id, date, role, username "
				+ "FROM transaction_header "
				+ "INNER JOIN user "
				+ "ON transaction_header.user_id = user.id");
		ArrayList<TH> thList = new ArrayList<>();
		try {
			while(result.next()) {
				
					thList.add(new TH(result.getInt("transaction_id"),
					 					result.getInt("user_id"),
					 					result.getString("username"),
					 					result.getString("role"),
					 					result.getString("date")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		thData = FXCollections.observableArrayList(thList);
		userTable.getItems().addAll(thData);
		
		sc = new Scene(bpane, 1000, 700);
	}
	
	void addComponent() {
		setTable();
		bp1.setCenter(userTable);
		bp2.setCenter(transactionTable);
		bp.setCenter(bp1);
		bp.setBottom(bp2);
		
		bp2.setPadding(new Insets(5, 0, 0, 0));
	}
	public void window() {

		wins.setPrefSize(bp.getPrefWidth(), bp.getPrefHeight());
		wins.setTitle("Transaction");
		wins.getContentPane().getChildren().add(bp);
		bpane.setCenter(wins);
	}
	
	public void setTable() {
		
		TableColumn transidK = new TableColumn<>("ID");
		TableColumn userK = new TableColumn<>("User ID");
		TableColumn userNameK = new TableColumn<>("User name");
		TableColumn userRoleK = new TableColumn<>("User role");
		TableColumn dateK = new TableColumn<>("Date");
		
		transidK.setCellValueFactory(new PropertyValueFactory<>("transaction_id"));
		userK.setCellValueFactory(new PropertyValueFactory<>("user_id"));
		userNameK.setCellValueFactory(new PropertyValueFactory<>("username"));
		userRoleK.setCellValueFactory(new PropertyValueFactory<>("role"));
		dateK.setCellValueFactory(new PropertyValueFactory<>("date"));

		transidK.setPrefWidth(sc.getWidth()/5);
		userK.setPrefWidth(sc.getWidth()/5);
		userNameK.setPrefWidth(sc.getWidth()/5);
		userRoleK.setPrefWidth(sc.getWidth()/5);
		dateK.setPrefWidth(sc.getWidth()/5);


		userTable.getColumns().addAll(transidK,userK, userNameK, userRoleK, dateK);

		TableColumn transIdFK = new TableColumn<>("ID");
		TableColumn nameFK = new TableColumn<>("Food Name");
		TableColumn typeFK = new TableColumn<>("Food Type");
		TableColumn priceFK = new TableColumn<>("Food Price");
		TableColumn qtyFK = new TableColumn<>("Quantity");
		TableColumn totalPriceFK = new TableColumn<>("Total Price");
		
		transIdFK.setCellValueFactory(new PropertyValueFactory<>("trans_id"));
		nameFK.setCellValueFactory(new PropertyValueFactory<>("food_name"));
		typeFK.setCellValueFactory(new PropertyValueFactory<>("food_type"));
		priceFK.setCellValueFactory(new PropertyValueFactory<>("food_price"));
		qtyFK .setCellValueFactory(new PropertyValueFactory<>("quant"));
		totalPriceFK.setCellValueFactory(new PropertyValueFactory<>("total_price"));

		transIdFK.setPrefWidth(sc.getWidth()/6);
		nameFK.setPrefWidth(sc.getWidth()/6);
		typeFK.setPrefWidth(sc.getWidth()/6);
		priceFK.setPrefWidth(sc.getWidth()/6);
		qtyFK.setPrefWidth(sc.getWidth()/6);
		totalPriceFK.setPrefWidth(sc.getWidth()/6);
		
		userTable.setOnMouseClicked(new EventHandler<Event>() {
			public void handle(Event event) {
				TH terpilih = userTable.getSelectionModel().getSelectedItem();
				int idTerpilih = terpilih.getTransaction_id();
				
				
				ArrayList<TD> tdList = new ArrayList<>();
				
				try {
					ResultSet result = Connect.getconnect().read("SELECT * FROM transaction_detail INNER JOIN food"
							+ " ON transaction_detail.food_id = food.id WHERE transaction_detail.transaction_id = " + idTerpilih);
					
					transactionTable.getItems().removeAll(transactionTable.getItems());
					while(result.next()) {
						TD baru = new TD(result.getInt("transaction_id"), result.getString("name"), result.getString("type"), result.getInt("price"), result.getInt("quantity"), result.getInt("total_price"));
						tdList.add(baru);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
				
				transactionTable.getItems().addAll(tdList);
				
				
				
			};
		});
		
		transactionTable.getColumns().addAll(transIdFK,nameFK, typeFK, priceFK, qtyFK, totalPriceFK);
	}
	
	
	public Scene getTransactionHistoryAdmin() {
		return sc;
	}
	
	
	
	@Override
	public void start(Stage arg0) throws Exception {
		Stage st = new Stage();
		TransactionHistoryAdmin scne = new TransactionHistoryAdmin();
		st.setScene(scne.getTransactionHistoryAdmin());
		st.show();
	}

}
