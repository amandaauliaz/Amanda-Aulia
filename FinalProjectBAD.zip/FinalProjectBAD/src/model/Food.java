package model;

public class Food {

	private Integer foodID ;
	private String foodName;
	private String foodType;
	private Integer foodPrice;
	private Integer foodStock;
	public Integer getFoodID() {
		return foodID;
	}
	public void setFoodID(Integer foodID) {
		this.foodID = foodID;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public String getFoodType() {
		return foodType;
	}
	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}
	public Integer getFoodPrice() {
		return foodPrice;
	}
	public void setFoodPrice(Integer foodPrice) {
		this.foodPrice = foodPrice;
	}
	public Integer getFoodStock() {
		return foodStock;
	}
	public void setFoodStock(Integer foodStock) {
		this.foodStock = foodStock;
	}
	public Food(Integer foodID, String foodName, String foodType, Integer foodPrice, Integer foodStock) {
		super();
		this.foodID = foodID;
		this.foodName = foodName;
		this.foodType = foodType;
		this.foodPrice = foodPrice;
		this.foodStock = foodStock;
	}


	

	
	
	
	
	
	
}
