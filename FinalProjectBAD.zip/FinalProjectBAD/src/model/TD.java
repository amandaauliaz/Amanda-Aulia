package model;

public class TD {
	private int trans_id;
	private String food_name;
	private String food_type;
	private int food_price;
	private int quant;
	public TD(int trans_id, String food_name, String food_type, int food_price, int quant, int total_price) {
		super();
		this.trans_id = trans_id;
		this.food_name = food_name;
		this.food_type = food_type;
		this.food_price = food_price;
		this.quant = quant;
		this.total_price = total_price;
	}
	public int getTrans_id() {
		return trans_id;
	}
	public void setTrans_id(int trans_id) {
		this.trans_id = trans_id;
	}
	public String getFood_name() {
		return food_name;
	}
	public void setFood_name(String food_name) {
		this.food_name = food_name;
	}
	public String getFood_type() {
		return food_type;
	}
	public void setFood_type(String food_type) {
		this.food_type = food_type;
	}
	public int getFood_price() {
		return food_price;
	}
	public void setFood_price(int food_price) {
		this.food_price = food_price;
	}
	public int getQuant() {
		return quant;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}
	public int getTotal_price() {
		return total_price;
	}
	public void setTotal_price(int total_price) {
		this.total_price = total_price;
	}
	private int total_price;
}
