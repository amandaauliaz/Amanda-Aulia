package model;

public class TH {
		int transaction_id;
		int user_id;
		String username;
		public TH(int transaction_id, int user_id, String username, String role, String date) {
			super();
			this.transaction_id = transaction_id;
			this.user_id = user_id;
			this.username = username;
			this.role = role;
			this.date = date;
		}
		String role;
		String date;
		public int getTransaction_id() {
			return transaction_id;
		}
		public void setTransaction_id(int transaction_id) {
			this.transaction_id = transaction_id;
		}
		public int getUser_id() {
			return user_id;
		}
		public void setUser_id(int user_id) {
			this.user_id = user_id;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
}
